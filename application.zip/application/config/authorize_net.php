<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['api_login_id'] = '2PuV95kr';
$config['api_transaction_key'] = '82kS4vW9587S7bWk'; //Simon
$config['arb_api_url'] = 'https://apitest.authorize.net/xml/v1/request.api'; // TEST URL
#$config['arb_api_url'] = 'https://api.authorize.net/xml/v1/request.api'; // PRODUCTION URL 

/* EOF */